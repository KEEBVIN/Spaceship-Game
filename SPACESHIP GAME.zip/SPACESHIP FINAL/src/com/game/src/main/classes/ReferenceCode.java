package com.game.src.main.classes;

public class ReferenceCode {
	//***NOTE: some of the code I made myself but I did use code from the reference in my own implementation
	
	//reference code for the bullets, player,enemy,textures, menu (playlist)
	//realtutsgml:
	//https://www.youtube.com/playlist?list=PLWms45O3n--6KCNAEETGiVTEFvnqA7qCi

	
	//framework for game/ enemy behavior / original form of implementation of the game
	//brocode:
	//https://www.youtube.com/watch?v=oLirZqJFKPE&t=3126s
	
	
	//back ground (stars)
	//len pelletier
	//https://www.youtube.com/watch?v=MJh3blPxcQw
	
	
	//GUI
	//BroCode & Alex Lee
	//https://www.youtube.com/watch?v=5o3fMLPY7qY&t=271s
	//https://www.youtube.com/watch?v=Kmgo00avvEw
	
}
