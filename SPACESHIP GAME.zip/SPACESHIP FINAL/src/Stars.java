import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;

public class Stars extends Rectangle{
	double x;
	double y;
	double dx;
	double dy;
	int width = 1500;
	int height = 1000;
	int r;
	int g;
	int b;
	Color myColor;

	Stars(){
		
		r = (int)(1+(Math.random() * 255));
		g = (int)(1+(Math.random() * 255));
		b = (int)(1+(Math.random() * 255));
			
		myColor = new Color(r,g,b);
		x = (int) (1 + (Math.random() * width));
		y = 0;
		
		dx = 0;
		dy = (int) (2 + (Math.random() * 5));
	}
	
	
	public void draw(Graphics g) {
		//g.setColor(myColor);
		g.setColor(Color.white);
		g.fillRect((int)x,(int) y,(int) dy,(int) dy);
	}
	
	public void move() {
		x = x + dx;
		y = y + dy;
	}
	
	public double getY() {
		return y;
	}
	}
