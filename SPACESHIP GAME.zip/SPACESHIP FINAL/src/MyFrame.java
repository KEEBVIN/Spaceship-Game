import java.awt.Color;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.Random;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class MyFrame extends JFrame {
	GamePanel panel;
	JLabel label;
	
	MyFrame(){
		panel = new GamePanel();
		this.add(panel);
		this.setTitle("Project");
		this.setResizable(false);
		this.setBackground(Color.black);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.pack();
		
		
		this.setVisible(true);
		this.setLocationRelativeTo(null);
		
	
	}
	
	
}
