import java.awt.Graphics;
import java.util.LinkedList;

public class BG {
	private LinkedList<Stars> s = new LinkedList<Stars>();
	 Stars temp;
	 GamePanel game;
	 
	 
	public BG(GamePanel game) {
		this.game = game;
	}
	
	
	public void move() {
		for(int i = 0; i < s.size(); i++) {
			temp = s.get(i);
			
			if(temp.getY() >= 1000) {
				removeStars(temp);
			}
			temp.move();
			
		}

	}
	
	public void draw(Graphics g) {
		for(int i = 0; i < s.size(); i++) {
			temp = s.get(i);
			temp.draw(g);
		}
	}
	
	
	public void addStars(Stars star) {
		s.add(star);
	}
	
	public void removeStars(Stars star) {
		s.remove(star);
	}
	
}
