import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;

public class Menu {
	
	public Rectangle play = new Rectangle(600, 500, 300,100);
	public Rectangle help = new Rectangle(600, 650, 300,100);
	public Rectangle quit = new Rectangle(600, 800, 300,100);
	
	public void draw(Graphics g) {
		Graphics2D g2d = (Graphics2D) g;
		Font fnt0 = new Font("serif",Font.CENTER_BASELINE, 500);
		g.setFont(fnt0);
		g.setColor(Color.white);
		g.drawString("SHIP", 200, 450);
		
		Font fnt1 = new Font("arial",Font.BOLD,80);
		g.setFont(fnt1);
		g.drawString("Play", play.x + 75,play.y+77);
		g.drawString("Help", help.x + 75,help.y+77);
		g.drawString("Quit", help.x + 75,quit.y+77);
		g2d.draw(play);
		g2d.draw(help);
		g2d.draw(quit);
		
	}

}
