import java.awt.Font;
import java.awt.Graphics;

import javax.swing.JLabel;
import javax.swing.JTextPane;

public class End {
	int x;
	int y;
	GamePanel game;
	JLabel label = new JLabel();
	End(int x, int y,GamePanel game){
		this.x = x;
		this.y = y;
		this.game = game;
	}
	
	
	public void drawGO(Graphics g) {
		label.setFont(new Font("Serif",1,400));
	}
	
	public void drawVIC(Graphics g) {
		label.setFont(new Font("Serif",1,400));
		
	}

}
