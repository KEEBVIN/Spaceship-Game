import java.util.LinkedList;

import com.game.src.main.classes.EntityA;
import com.game.src.main.classes.EntityB;

public class Physics {
	
	int width = 1500;
	int height = 1000;
	int enemy_diameter = 32;
	
	public static boolean Collision(EntityA enta, EntityB entb) {
			
			if(enta.getBounds().intersects(entb.getBounds())) {
				return true;
			}
		
		return false;
	}
	
	public static boolean Collision(EntityB entb, EntityA enta) {
		
			if(entb.getBounds().intersects(enta.getBounds())) {
				return true;
			}
		
		return false;
	}
	
	
	
	
	
	
	
	
	//bounds notes for enemy kinda random placement
	
	/*if(tempE.getX() >= (game.GameW - game.BALL_DIAMETER)) {
	tempE.setXDirection(-tempE.xVelocity);
}
if(tempE.getX() <= 0) {
	tempE.setXDirection(++tempE.xVelocity);
}
if(tempE.getY() <= 0) {
	tempE.setYDirection(-tempE.yVelocity);
}
if(tempE.getY() >= game.GameH - game.BALL_DIAMETER) {
	tempE.setYDirection(-tempE.yVelocity);
}
*/

}
