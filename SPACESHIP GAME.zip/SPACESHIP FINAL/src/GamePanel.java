import java.awt.Color;

import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.LinkedList;
import java.util.Random;

import javax.swing.JPanel;

import com.game.src.main.classes.EntityA;
import com.game.src.main.classes.EntityB;


public class GamePanel extends JPanel implements Runnable{
	static final int GameW = 1500;
	static final int GameH = 1000;
	static final Dimension SCREEN_SIZE = new Dimension(GameW,GameH);
	static final int BALL_DIAMETER = 32;
	static final int PLAYER_SIZE = 30;
	static final int PLAYER_SPAWN_X = 750;
	static final int PLAYER_SPAWN_Y = 500;
	static final int PLAYER_SPEED = 10;
	static final int ENEMY_SPAWN_X = 750;
	static final int ENEMY_SPAWN_Y = 184;
	static final int BULLET_SIZE = 10;
	static final int BULLET_X = 0;
	static final int BULLET_Y = 0;
	
	Thread gameThread;
	Image image;
	Graphics graphics;
	
	Random random;
	
	Player player;
	Enemy enemy;
	int enemy_count = 1;
	int kills = 0;
	int total_kills = 0;
	
	Boss boss;
	
	Score score;
	Controller c;
	Bullet b;
	Stars s;
	BG ani;
	
	BufferedImage spriteSheet = null;
	Textures tex;
	SpriteSheet ss = new SpriteSheet(spriteSheet);
	
	Menu menu;
	
	public static int HP = 100 *4;
	public static int BOSS_HP = 100 * 4;
	
	LinkedList<EntityA> ea;
	LinkedList<EntityB> eb;
	
	
	GamePanel(){
		//instantiates everything
		newLoader();
		newTexture();
		newController();
		newPlayer();
		newEnemy();
		newBullet();
		newBG();
		this.addMouseListener(new MouseInput());
		
		ea = c.getEntityA();
		eb = c.getEntityB();
		//menu = new Menu();
		
		score = new Score(GameW,GameH);
		this.setFocusable(true);
		this.addKeyListener(new AL(this));
		this.setPreferredSize(SCREEN_SIZE);
		gameThread = new Thread(this);
		gameThread.start();
	}
	
	public void newPlayer() {
		//makes the player
		player = new Player(PLAYER_SPAWN_X,PLAYER_SPAWN_Y,tex,this,c);
		
	}
	public void newEnemy() {
		c.addEnemy(enemy_count);
	}
	
	
	public void newController() {
		c = new Controller(this,tex);
	}
	public void newBullet() {
		b = new Bullet(player.x,player.y,tex,this);
	}
	
	//stars
	public void newBG() {
		ani = new BG(this);
	}
	public void newTexture() {
		tex = new Textures(this);
	}
	
	
	public void newLoader() {
		BufferedImageLoader loader = new BufferedImageLoader();
		try{
			spriteSheet = loader.loadImage("/sprite_sheet.png");
			
		}catch(IOException e) {
			e.printStackTrace();
		}
	}

	public void paint(Graphics g) {
		//lets everything draw on screen
		image = createImage(getWidth(),getHeight());
		graphics = image.getGraphics();
		draw(graphics);
		g.drawImage(image,0,0,this);
	}
	
	public void draw(Graphics g) {
		
		// draws on screen
		player.draw(g);
		//enemy.draw(g);
		c.draw(g);
		
		//background animation
		ani.draw(g);
		
		//kills
		score.draw(g);
		
		
		
		//PLAYER HEALTH
		//base
		g.setColor(Color.gray);
		g.fillRect(5,5,400,50);
		//green
		g.setColor(Color.green);
		g.fillRect(5,5,HP,50);
		//red
		g.setColor(Color.red);
		g.drawRect(5,5,400,50);
		
		if(HP <= 0) {
			
		}
		
	}
	
	public void move() {

		//allows the movement
		player.move();
		//enemy.move();
		c.move();
		ani.move();
		
		if(kills >= enemy_count) {
			enemy_count += 1;
			total_kills += kills;
			
			kills = 0;
			c.addEnemy(enemy_count);
			System.out.println(total_kills);
			 if(total_kills >= 20) {
				
				System.exit(1);
				
			}
			
			
		}
		
		if(HP <= 0) {
			System.exit(1);
		}
		/*if(BOSS_HP <= 0) {
			System.exit(1);
		}*/
		//}
	}
	public void checkCollision() {
		//stops player at window edges
		if(player.x <= 0) {
			player.x = 0;
		}
		if(player.x >= GameW - PLAYER_SIZE) {
			player.x = GameW - PLAYER_SIZE;
		}
		if(player.y <= 0) {
			player.y = 0;
		}
		if(player.y >= GameH - PLAYER_SIZE) {
			player.y = GameH - PLAYER_SIZE;
		}
		
		//back ground animation
		if(true) {
			ani.addStars(new Stars());
		}
	}
	
	public int getEnemy_count() {
		return enemy_count;
	}

	public void setEnemy_count(int enemy_count) {
		this.enemy_count = enemy_count;
	}

	public int getKills() {
		return kills;
	}

	public void setKills(int kills) {
		this.kills = kills;
	}

	public void setTotalKills(int total_kills) {
		this.total_kills = total_kills;
	}
	public int getTotalKills() {
		return total_kills;
	}
	
	
	public void run(){
		//game loop 
		long lastTime = System.nanoTime();
		double amountofTicks = 60.0;
		double ns = 1000000000 / amountofTicks;
		double delta = 0;
		int updates = 0;
		int frames = 0;
		long timer = System.currentTimeMillis();
		
		while(true) {
			long now = System.nanoTime();
			delta += (now - lastTime)/ns;
			lastTime = now;
			if(delta >= 1) {
				move();
				checkCollision();
				repaint();
				updates++;
				delta--;
				//System.out.println("test");
			}
			frames++;
			if(System.currentTimeMillis() - timer > 1000) {
				timer +=1000;
				System.out.println(" Ticks: " + updates +" Fps: "+frames);
				updates = 0;
				frames = 0;
			}
		}
	}
	
	public BufferedImage getSS() {
		return spriteSheet;
	}
	
	// new movement
	public void keyPressed(KeyEvent e) {
		int key = e.getKeyCode();
		
		//if(state == STATE.GAME) {
			
		if(key == KeyEvent.VK_W) {
			player.setYDirection(-PLAYER_SPEED);
			player.move();
		}
		else if(key == KeyEvent.VK_A) {
			player.setXDirection(-PLAYER_SPEED);
			player.move();
		}
		else if(key == KeyEvent.VK_S) {
			player.setYDirection(PLAYER_SPEED);
			player.move();
		}
		else if(key == KeyEvent.VK_D) {
			player.setXDirection(PLAYER_SPEED);
			player.move();
		}
		else if(key == KeyEvent.VK_I) {
			c.addEntity(new Bullet(player.getX(), player.getY(),tex,this));
		}
		
		
	}
	
	
	public void keyReleased(KeyEvent e) {
		int key = e.getKeyCode();
		if(key == KeyEvent.VK_W) {
			player.setYDirection(0);
			player.move();
		}
		else if(key == KeyEvent.VK_A) {
			player.setXDirection(0);
			player.move();
		}
		else if(key == KeyEvent.VK_S) {
			player.setYDirection(0);
			player.move();
		}
		else if(key == KeyEvent.VK_D) {
			player.setXDirection(0);
			player.move();
		}
	}

	
}
