import java.awt.Graphics;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.LinkedList;
import java.util.Random;

import com.game.src.main.classes.EntityA;
import com.game.src.main.classes.EntityB;

public class Controller {
	private LinkedList<EntityA> ea = new LinkedList<EntityA>();
	private LinkedList<EntityB> eb = new LinkedList<EntityB>();
	
	GamePanel game;
	Player player;
	Textures tex;
	EntityA enta;
	EntityB entb;
	Random r = new Random();
	int enemy_size = 25;
	
	//spawn points
	int spawn_x1 = 750;
	int spawn_y1 = 10;
	
	int spawn_x2 = 325;
	int spawn_y2 = 500;
	
	int spawn_x3 = 750;
	int spawn_y3 = 950;
	
	int spawn_x4 = 1450;
	int spawn_y4 = 500;
	
	public Controller(GamePanel game, Textures tex) {
		this.game = game;
		this.tex = tex;
		
		
		//test to see if it spawns
		//addEntity(new Enemy(500,500,30,30,tex));
	}
	
	
	//iterates through LL
	public void move() {
		//ENTITY A
		for(int i = 0; i < ea.size(); i++) {
			enta = ea.get(i);
			enta.move();
		}
		
		//Entity B
		for(int i = 0; i < eb.size(); i++) {
			entb = eb.get(i);
			entb.move();
		}
		
	}
	
	//loop to go through LL and draw each bullet
	public void draw(Graphics g) {
		//drawing the bullet
		
		//ENTITY A
		for(int i = 0; i < ea.size(); i++) {
			enta = ea.get(i);
			enta.draw(g);
		}
		//ENTITY B
		for(int i = 0; i < eb.size(); i++) {
			entb = eb.get(i);
			entb.draw(g);
		}
		
	}
	
	public void addEntity(EntityA obj ) {
		ea.add(obj);
	}
	public void removeEntity(EntityA obj ) {
		ea.remove(obj);
	}
	
	public void addEntity(EntityB obj ) {
		eb.add(obj);
	}
	public void removeEntity(EntityB obj ) {
		eb.remove(obj);
	}
	
	public void addEnemy(int count) {
		int max = 4;
		int min = 1;
		//different spawn points in the screen
		for(int i = 0; i < count; i++) {
			
		int r = (int) (Math.random() * (max - min + 1) + min);
		if(r == 1) {
			
			addEntity(new Enemy(spawn_x1,spawn_y1, enemy_size,enemy_size,tex,this,game));
		}
		else if(r == 2) {
			
				addEntity(new Enemy(spawn_x2,spawn_y2, enemy_size,enemy_size,tex,this,game));
		}
		else if(r == 3) {
			
				addEntity(new Enemy(spawn_x3,spawn_y3, enemy_size,enemy_size,tex,this,game));
		}
		else if(r == 4) {

				addEntity(new Enemy(spawn_x4,spawn_y4, enemy_size,enemy_size,tex,this,game));
		}
		else
			System.out.println("ERROR");
		}
	}
	
	public LinkedList<EntityA> getEntityA(){
		return ea;
	}
	
	public LinkedList<EntityB> getEntityB(){
		return eb;
	}

	//bounds
	
	/*if(tempE.getX() >= (game.GameW - game.BALL_DIAMETER)) {
	tempE.setXDirection(-tempE.xVelocity);
}
if(tempE.getX() <= 0) {
	tempE.setXDirection(++tempE.xVelocity);
}
if(tempE.getY() <= 0) {
	tempE.setYDirection(-tempE.yVelocity);
}
if(tempE.getY() >= game.GameH - game.BALL_DIAMETER) {
	tempE.setYDirection(-tempE.yVelocity);
}
*/
	

}
