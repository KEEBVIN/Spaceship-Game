import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import java.util.Random;

import com.game.src.main.classes.EntityA;
import com.game.src.main.classes.EntityB;

public class Enemy extends GameObject implements EntityB{
	
	Random random;
	
	int gameW = 1500;
	int gameH = 1000;
	int size = 32;
	int width;
	int height;
	int xVelocity;
	int yVelocity;
	int ENEMY_SPEED = 7;
	int BULLET_SIZE = 5;
	int BULLET_SPEED = 15;
	GamePanel game;
	Textures tex;
	Controller c;
	Enemy(int x, int y, int width, int height, Textures tex,Controller c, GamePanel game){
		super(x,y);
		
		this.width = width;
		this.height = height;
		this.tex = tex;
		this.c = c;
		this.game = game;
		
		
		//dictates the direction it goes in a random manner
		random = new Random();
		
		int randomXDirection = random.nextInt(2);
		
		if(randomXDirection == 0) {
			randomXDirection--;
			}
		setXDirection(randomXDirection * ENEMY_SPEED);
		
		int randomYDirection = random.nextInt(2);
		
		if(randomYDirection == 0) {
			randomYDirection--;
			}
		setYDirection(randomYDirection * ENEMY_SPEED);
		
		
		
		}
	
	public void setXDirection(int randomXDirection) {
		xVelocity = randomXDirection;
	}
	public void setYDirection(int randomYDirection) {
		yVelocity = randomYDirection;
	}
	public void move() {
		x += xVelocity;
		y += yVelocity;
		
		//stays within the screen
		if(getX() >= (gameW - size)) {
			setXDirection(-xVelocity);

		}
		if(getX() <= 0) {
			setXDirection(++xVelocity);
			
		}
		if(getY() <= 0) {
			setYDirection(-yVelocity);
			
		}
		if(getY() >= gameH - size) {
			setYDirection(-yVelocity);
			
		}
		//removes enemy if there is a collision with the bullet
		for(int i=0 ; i < game.ea.size(); i++) {
			EntityA tempEnt = game.ea.get(i);
		
		if(Physics.Collision(this, tempEnt)) {
			c.removeEntity(tempEnt);
			c.removeEntity(this);
			game.setKills(game.getKills() + 1);
			game.setTotalKills(game.getKills()+1);
		}
		}
	}
	
	public double getX() {
		return x;
	}
	public double getY() {
		return y;
	}
	
	public void draw(Graphics g) {
		//g.setColor(Color.yellow);
		//g.fillOval(x, y, height, width);
		g.drawImage(tex.enemy, (int)x,(int) y, null);
	}
	
	public Rectangle getBounds() {
		
		return new Rectangle((int)x,(int)y,32,32);
	}

	

}
