import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class GUI implements ActionListener{
	JFrame frame;
	JPanel panel;
	JPanel text;
	JButton play;
	JButton help;
	JButton quit;
	ImageIcon image1;
	ImageIcon image2;
	JLabel label;
	
	public GUI() {
	
		play = new JButton("Play");
		play.setBounds(200,205,100,60);
		play.addActionListener(this);
		
		help = new JButton("Help");
		help.setBounds(200,275,100,60);
		help.addActionListener(this);
		
		quit = new JButton("Quit");
		quit.setBounds(200,345,100,60);
		quit.addActionListener(this);
		
		
		panel = new JPanel();
		panel.setBackground(Color.black);
		panel.setBounds(0,0,500,500);
		label = new JLabel("SHIP");
		label.setFont(new Font("Serif",1,200));
		panel.add(label);
		
		
		frame = new JFrame("Menu");
		frame.setSize(new Dimension(500,500));
		frame.setLayout(null);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.add(play);
		frame.add(help);
		frame.add(quit);
		frame.add(panel);
		
		
		frame.setLocationRelativeTo(null);
		frame.setVisible(true);
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		
		if(e.getSource() == play) {
		MyFrame frame = new MyFrame();
			
		}
		
		if(e.getSource() == help) {
			
		}
		
		if(e.getSource() == quit) {
			System.exit(1);
		}
		
	}
	

	
}
