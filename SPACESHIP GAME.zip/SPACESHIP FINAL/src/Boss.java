import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.util.Random;

import com.game.src.main.classes.EntityA;
import com.game.src.main.classes.EntityB;

public class Boss extends GameObject implements EntityB{
	
	int size = 50;
	int BOSS_SPEED = 3;
	int xVel;
	int yVel;
	int gameW = 1500;
	int gameH = 1000;
	Controller c;
	GamePanel game;
	
	Random random;

	public Boss(double x, double y, int size, Controller c, GamePanel game) {
		super(x, y);
		this.size = size;
		this.c = c;
		this.game = game;
		
		random = new Random();
		
		int randomXDirection = random.nextInt(2);
		
		if(randomXDirection == 0) {
			randomXDirection--;
			}
		setXDirection(randomXDirection * BOSS_SPEED);
		
		int randomYDirection = random.nextInt(2);
		
		if(randomYDirection == 0) {
			randomYDirection--;
			}
		setYDirection(randomYDirection * BOSS_SPEED);
	}
	
	public void setXDirection(int randomXDirection) {
		xVel = randomXDirection;
	}
	public void setYDirection(int randomYDirection) {
		yVel = randomYDirection;
	}
	public void move() {
		x += xVel;
		y =+ yVel;
		
		if(getX() >= (gameW - size)) {
			setXDirection(-xVel);
		}
		if(getX() <= 0) {
			setXDirection(++xVel);
		}
		if(getY() <= 0) {
			setYDirection(-yVel);
		}
		if(getY() >= gameH - size) {
			setYDirection(-yVel);
		}
		
		for(int i = 0; i < game.ea.size(); i++) {
			EntityA tempEnt = game.ea.get(i);
		//if bullet hits boss
		if(Physics.Collision(this, tempEnt)) {
			c.removeEntity(tempEnt);
			GamePanel.BOSS_HP -= 25;
			
		}
		}
		
	}
	public double getY() {
		
		return y;
	}
	
	public double getX() {
		
		return x;
	}
	
	public void draw(Graphics g) {
		g.setColor(Color.red);
		g.fillRect((int)x,(int) y, size, size);
	}

	@Override
	public Rectangle getBounds() {
		return new Rectangle((int)x,(int)y,size,size);
	}

}
