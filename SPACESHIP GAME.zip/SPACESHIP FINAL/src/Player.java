import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.image.BufferedImage;

import javax.swing.JFrame;
import javax.swing.JLabel;

import com.game.src.main.classes.EntityA;
import com.game.src.main.classes.EntityB;

public class Player extends GameObject implements EntityA{
	JLabel label;
	int yVelocity;
	int xVelocity;
	int PLAYER_SPEED = 10;
	
	int size = 25;

	 GamePanel game;
	 Controller c;
	 Textures tex;
	
	
	
	Player(double x, double y, Textures tex, GamePanel game, Controller c){
		super(x,y);
		this.tex = tex;
		this.game = game;
		this.c = c;
	}
	

	
	
	public void setXDirection(int xDirection) {
		xVelocity = xDirection;
	}
	public void setYDirection(int yDirection) {
		yVelocity = yDirection;
	}
	
	public void move() {
		y = y + yVelocity;
		x = x + xVelocity;
		
		//if player gets hit
		
		for(int i = 0; i < game.eb.size(); i++ ) {
			
			EntityB tempEnt = game.eb.get(i);
			
			if(Physics.Collision(this, tempEnt)) {
				
				c.removeEntity(tempEnt);
				GamePanel.HP -=50;
				game.setKills(game.getKills()+1);
				
			}
		}
	}

	public void draw(Graphics g) {
		g.drawImage(tex.player,(int)x,(int)y,null);
	}
	
	public Rectangle getBounds() {
		
		return new Rectangle((int)x,(int)y,32,32);
	}

	public double getX() {
		return x;
	}
	public double getY() {
		return y;
	}

}
