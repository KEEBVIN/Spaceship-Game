import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;

import com.game.src.main.classes.EntityA;

public class Bullet extends GameObject implements EntityA{

	double speed = 50;
	
	Textures tex;
	GamePanel game;
	public Bullet(double x, double y, Textures tex, GamePanel game) {
		super(x,y);
		this.tex = tex;
		this.game = game;
		
	}
	
	public void move() {
		y -= speed;
	}

	public void draw(Graphics g) {
		g.drawImage(tex.bullet, (int)x,(int)y,null);
	}
	
	public Rectangle getBounds() {
		
		return new Rectangle((int)x,(int)y,32,32);
	}
	
	public double getY() {
		return y;
	}
	public double getX() {
		return x;
	}


}
