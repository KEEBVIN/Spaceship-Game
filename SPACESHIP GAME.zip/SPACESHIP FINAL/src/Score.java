import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Rectangle;

public class Score  extends Rectangle{
	int GameW;
	int GameH;
	int player;
	
	Score(int GameW, int GameH){
		this.GameW = GameW;
		this.GameH = GameH;
	}
	
	public void draw(Graphics g) {
		g.setColor(Color.white);
		g.setFont(new Font("Sarif", 1,60));
		
		
	}
}
